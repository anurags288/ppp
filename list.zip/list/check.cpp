#include<iostream>
using namespace std;

bool check(int [], int, int);

int main()
{

	int a[10],sa, ele;

	cout<<"\nEnter the size of Set A:";
	cin>>sa;

	cout<<"\n\nEnter the elements of Set A.\n";

	for(int i=0;i<sa;i++)
	{
		cout<<"\nEnter the element number "<<i+1<<":";
		cin>>a[i];
	}

	cout<<"\nEnter the element you want to search in the Set:";
	cin>>ele;

	cout<<check(a,sa,ele);

return 0;

}


bool check(int a[], int sa, int ele)
{

	for(int i=0;i<sa;i++)
	{
		if(a[i] == ele)
			return true;
	}

	return false;

}
