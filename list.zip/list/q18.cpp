#include<iostream>
#include<cmath>
using namespace std;

class graph
{
	int a[20][20];
	int n;

	public:
	graph();
	void enter();
	void show();
	int calc_paths();
};


graph::graph()
{
	for(int i=0;i<20;i++)
	{
		for(int j=0;j<20;j++)
		{
			a[i][j] = 0;
		}
	}
}


void graph::enter()
{
	string ch;
	cout<<"\nEnter the number of elements you want to enter in the set:";
	cin>>n;

	cout<<"\nEnter the elements in the set as characters:";
	cin>>ch;

	int ele;

	cout<<"\nEnter the number of edges:";
	cin>>ele;

	if(ele >= 0 && ele <= pow(2,n))
	{
		cout<<"\n\nEnter the edges.";

		for(int i=0;i<ele;i++)
		{
			string c;
				
			cin>>c;

			a[c[0]-97][c[2]-97] = 1;
			a[c[2]-97][c[0]-97] = 1;
		}
	}

	else
	{
		cout<<"\nNumber is invalid.";
	}

	show();
}


void graph::show()
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<a[i][j]<<" ";
		}
		cout<<endl;
	}
}


int graph::calc_paths()
{
	char start, dest;	
	int p, s, d, paths;
	
	cout<<"\nEnter the starting vertex:";
	cin>>start;

	cout<<"\nEnter the final vertex:";
	cin>>dest;
	
	s = int(start)-97;
	d = int(dest)-97;
	cout<<"\nEnter the length of path your want to check:";
	cin>>p;

	paths = p;

	int b[n][n];

	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			b[i][j] = a[i][j];
		}
	}

	int c[n][n];

	while(p > 1)
	{
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				c[i][j] = 0;
	
				for(int k=0;k<n;k++)
				{
					c[i][j] += a[i][k] * b[k][j];
				}
			}
		}
		
		p--;

	
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			a[i][j] = c[i][j];

	}


	show();	

	cout<<"\nThe number of paths of length "<<paths<<" are:"<<a[s][d];

	                                                                                                                                                
}


int main()
{
	graph g;

	g.enter();

	g.calc_paths();

return 0;
}
