#include"rel.cpp"

int main()
{
	

	int choice;
	char ch;

	do
	{
		relation r;

		cout<<"\n1.Enter 1 to check whether the relation is not reflexive or not.";
		cout<<"\n2.Enter 2 to check whether the relation is not symmetric or not.";
		cout<<"\n3.Enter 3 to check whether the relation is not transitive or not.";
		cout<<"\n4.Enter 4 to check whether the relation is not antisymmetric or not.";
		cout<<"\n\nEnter your choice:";	
		cin>>choice;

		switch(choice)
		{
			case 1:r.enter();
			       if(r.reflexive())
			       {
					cout<<"\nThe relation is reflexive.";
			       }

			       else
	                       {
		                        cout<<"\nThe relation is not reflexive.";
	                       }
	
			       break;

			case 2: r.enter();
				if(r.symmetric())
				{
					cout<<"\nThe relation is symmetric.";
				}

				else
				{	
					cout<<"\nThe relation is not symmetric.";
				}
	
				break;
				
			case 3: r.enter();
				if(r.transitive())
				{
					cout<<"\nThe relation is transitive.";
				}

				else
				{
					cout<<"\nThe relation is not transitive.";
				}

				break;

			case 4: r.enter();
				if(r.antisymmetric())
				{
					cout<<"\nThe relation is antisymmetric.";
				}

				else
				{
					cout<<"\nThe relation is not antisymmetric.";
				}

				break;
					

				default: cout<<"\nInvalid Input."; break;
		}

		cout<<"\nDo you want to make another choice(y/n)?";
		cin>>ch;
	}while(ch == 'y' || ch == 'Y');


return 0;
}
