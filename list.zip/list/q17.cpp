#include<iostream>
#include<cmath>
#include<cstdlib>
using namespace std;

class q17
{
	int a[20][20];
	int n;

	public:
	q17();
	void enter();
	void disp();
	void calc_outdeg(char);
	void calc_indeg(char);
};

q17::q17()
{
	n = 0;

	for(int i=0;i<20;i++)
		for(int j=0;j<20;j++)
			a[i][j] = 0;
}


void q17::enter()
{
	string ch;

	cout<<"\nEnter the number of elements you want to enter in the set:";
	cin>>n;

	cout<<"\nEnter the elements in the set as characters:";
	cin>>ch;

	int num;

	cout<<"\nEnter the number of edges:";
	cin>>num;

	if(num >= 0 && num <= pow(num,2))
	{
		cout<<"\nEnter the edges.";
		for(int i=0;i<num;i++)
		{
			string s;

			cin>>s;

			a[s[0]-97][s[2]-97] = 1;
		}
	
		disp();
		
	char c;
	
	cout<<"\nEnter the vertex whose out degree and in degree is to be calculated:";
	cin>>c;

	calc_indeg(c);
	calc_outdeg(c);
		
	}

	else
	{
		cout<<"\nThe number of elements are Invalid.";
		exit(0);
	}
	
}

void q17::disp()
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
			cout<<a[i][j]<<" ";
		
		cout<<endl;
	}
}


void q17::calc_indeg(char c)
{
	int sum = 0;
	for(int i=0;i<n;i++)
	{
		sum += a[i][int(c)-97];
	}

	cout<<"\nThe in degreeof the vertex:"<<sum;
}


void q17::calc_outdeg(char c)
{
	int sum = 0;
	for(int i=0;i<n;i++)
	{
		sum += a[int(c)-97][i];
	}

	cout<<"\nThe out degree of the vertex:"<<sum;
}


int main()
{
	q17 g;

	g.enter();

return 0;
}			


