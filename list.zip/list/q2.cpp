#include<iostream>
using namespace std;

class set
{
	int a[20], size;

	public:
	
	void enter();
	void disp();
	bool subset(set &);
	set union_array(set &);
	set intersection(set &);
	set setDifference(set &);
	void cartProduct(set &);
	void complement();
};


void set::enter()
{
	cout<<"\nEnter the size of the Set you want to enter:";
	cin>>size;

	cout<<"\nEnter the elements of the Set:";
	for(int i=0;i<size;i++)
	{
		cout<<"\nEnter the element number "<<i+1<<":";
		cin>>a[i];
	}
}


void set::disp()
{
	cout<<"\nThe elements of the Set are:";

	for(int i=0;i<size;i++)
		cout<<a[i]<<" ";
}


bool set::subset(set &s)
{
	int temp=0;

	for(int i=0;i<size;i++)
	{
		for(int j=0;j<s.size;j++)
		{
			if(a[i] == s.a[j])
				temp++;
		}
	}

	if(temp == s.size)
		return true;

	else
		return false;
}


set set::union_array(set &s)
{
	set ob;
	int k=0;
	
	for(int i=0;i<size;i++)
	{
		ob.a[k] = a[i];
		k++;
	}

	for(int j=0;j<s.size;j++)
	{
		ob.a[k] = s.a[j];
		k++;
	}

	for(int i=0;i<k;i++)
	{
		for(int j=i+1;j<k;j++)
		{
			if(ob.a[i] == ob.a[j])
			{
				for(int t=j;t<k-1;t++)
				{
					ob.a[t] = ob.a[t+1];
				}

				k--;
			}
		}
	}

	ob.size = k;
	return ob;
}


set set::intersection(set &s)
{
	set ob;
	int k=0;
	
	for(int i=0;i<size;i++)
	{
		for(int j=0;j<s.size;j++)
		{
			if(a[i] == s.a[j])
			{
				ob.a[k] = a[i];
				k++;
			}
		}
	}

	ob.size = k;
	return ob;
}


set set::setDifference(set &s)
{
	set ob;

	int i=0,j,k=0;

	while(i != size)
	{
		int flag = 0;

		for(j=0;j<s.size;j++)
		{
			if(a[i] == s.a[j])
			{
				flag = 1;
				break;
			}
		}

		if(flag == 0)
		{
			ob.a[k] = a[i];
			k++;
		}

		i++;
	}

	ob.size = k;

	return ob;

}


void set::cartProduct(set &s)
{
	for(int i=0;i<size;i++)
	{
		for(int j=0;j<s.size;j++)
		{
			cout<<a[i]<<" "<<s.a[j]<<" ";
		}

		cout<<endl;
	}
}



void set::complement()
{
	set s1,s2;

	int i,j,k=0;

	cout<<"\nEnter the size you want to enter in the Universal Set:";
	cin>>s1.size;

	cout<<"\nEnter the elements of the Universal Set.";
	for(int i=0;i<s1.size;i++)
	{
		cout<<"\nEnter the element number "<<i+1<<":";
		cin>>s1.a[i];
	}

	
	bool b = s1.subset(*this);

	if(s1.size > size && b == true)
	{
		for(i=0;i<s1.size;i++)
		{	int flag = 0;
			for(j=0;j<size;j++)
			{
				if(s1.a[i] == a[j])
				{
					flag++;
				}
			}

			if(flag == 0)
			{
				s2.a[k] = s1.a[i];
				k++;
			}
		}

		s2.size = k;

		s2.disp();
	}

	else
	{
		cout<<"\nComplement is not possible.";
		
	}

}

		

int main()
{
	int choice;
	char ch;

	set ob1,ob2,ob3;

	do
	{
		cout<<"\n1.Enter 1 to enter the Set.";
		cout<<"\n2.Enter 2 to display the Set.";
		cout<<"\n3.Enter 3 to check whether a Set is a Subset of the other or not.";
		cout<<"\n4.Enter 4 to find the union of the Sets.";
		cout<<"\n5.Enter 5 to find the intersection of the Sets.";
		cout<<"\n6.Enter 6 to find Set Differece of the Sets.";
		cout<<"\n7.Enter 7 to find Symmetric Difference of the Sets.";
		cout<<"\n8.Enter 8 to find the cartesian Product of the Sets.";
		cout<<"\n9.Enter 9 to find the Complement of the Set.";

		cout<<"\n\nEnter your choice:";
		cin>>choice;

		switch(choice)
		{
			case 1:{ cout<<"\nEnter the first Set.";
				ob1.enter();

				cout<<"\nEnter the second Set.";
				ob2.enter();

				break; }

			case 2: { ob1.disp();
				  ob2.disp();

				  break; }

			case 3: { bool b = ob1.subset(ob2);

				 cout<<b;

				 break; }

			case 4: { ob3 = ob1.union_array(ob2);
				  ob3.disp();
				  break; }

			case 5:{ ob3 = ob1.intersection(ob2);
				 ob3.disp();				
				 break; }

			case 6:{ ob3 = ob1.setDifference(ob2);
				 ob3.disp();				
				 break; }

			case 7: { set ob4=ob1.setDifference(ob2);
				  set ob5=ob2.setDifference(ob1);
				  ob3=ob4.union_array(ob5);
				  ob3.disp();
				  break; }

			case 8: { ob1.cartProduct(ob2);
				  break; }

			case 9: { int a;
				
				  cout<<"\n\n1.Enter 1 to find the complement of first Set.";
				  cout<<"\n2.Enter 2 to find the complement of second Set.";
				  cout<<"\n\nEnter your choice:";
				  cin>>a;

				  if(a == 1)
				  {
					ob1.complement();
					
				  }

				  else if(a == 2)
				  {
 					ob2.complement();
					
				  }

				break;

				}

			default: {cout<<"\nInvalid Input.";  break;}

		}

		cout<<"\nDo you want to enter another choice(y/n)?";
		cin>>ch;
	}while(ch == 'y' || ch == 'Y');

return 0;

}
