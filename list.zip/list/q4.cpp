#include "rel.cpp"

int main()
{
	int choice;
	char ch;

	do
	{
		relation r;

		cout<<"\n1.Enter 1 to check whether the relation is equivalent or not.";
		cout<<"\n2.Enter 2 to check whether the relation is partial order relation or not,";
		cout<<"\n3.Enter 3 to exit.";
		cout<<"\n\nEnter your choice:";
		cin>>choice;

		switch(choice)
		{
			case 1: r.enter();
				if(r.reflexive() && r.symmetric() && r.transitive())
					cout<<"\nThe relation is equivalent.";

				else
					cout<<"\nThe relation is not equivalent.";

				break;

			case 2: r.enter();
				if(r.reflexive() && r.antisymmetric() && r.transitive())
					cout<<"\nThe relation is partial order relation.";

				else
					cout<<"\nThe relation is not partial order relation.";

				break;

			case 3: break;

			default: cout<<"\nInvalid Input.";  break;
		}

		cout<<"\nDo you want to enter another choice(y/n)?";
		cin>>ch;
	}while(ch == 'y' || ch == 'Y');

return 0;
}
		

