#include<iostream>
using namespace std;

class relation
{
	int a[20][20];
	int n;

	public:
	relation();
	void enter();
	void show();
	bool reflexive();
	bool symmetric();
	bool transitive();
	bool antisymmetric();
};

relation::relation()
{
	for(int i=0;i<20;i++)
		for(int j=0;j<20;j++)
			a[i][j] = 0;

	n = 0;

}


void relation::enter()
{

	cout<<"\nEnter the no. of elements in the set:";
	cin>>n;

	int ele;
	cout<<"\nEnter the number of elements you want to enter in the relation:";
	cin>>ele;

	string c;

	for(int i=0;i<ele;i++)
	{
		cin>>c;

		a[c[0]-97][c[2]-97] = 1;
	}

	cout<<"\nThe relation in matrix form are:"<<endl;

	show();
}


void relation::show()
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
			cout<<a[i][j]<<" ";

		cout<<endl;
	}
}


bool relation::reflexive()
{
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			if(i == j)
				if(a[i][j] != 1)
					return false;

	return true;
}


bool relation::symmetric()
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(a[i][j] == 1 && a[i][j] != a[j][i])
				return false;
		}
	}

	return true;
} 


bool relation::transitive()
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			for(int k=0;k<n;k++)
			{
				if(a[i][k] == 1 && a[k][j] == 1&& a[i][j] != 1 )
					return false;
			}
		}
	}

	return true;
}


bool relation::antisymmetric()
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(a[i][j] == 1 && a[j][i] ==1 && i != j)
				return false;
		}
	}

	return true;
}


