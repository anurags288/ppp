#include<iostream>
#include<cmath>
using namespace std;

class graph
{
	int a[20][20];
	int n;

	public:
	graph();
	void enter();
	void show();
	bool check_complete();
};


graph::graph()
{
	for(int i=0;i<20;i++)
	{
		for(int j=0;j<20;j++)
		{
			a[i][j] = 0;
		}
	}
}


void graph::enter()
{
	string ch;
	cout<<"\nEnter the number of elements you want to enter in the set:";
	cin>>n;

	cout<<"\nEnter the elements in the set as characters:";
	cin>>ch;

	int ele;

	cout<<"\nEnter the number of edges:";
	cin>>ele;

	if(ele >= 0 && ele <= pow(n,2))
	{
		cout<<"\n\nEnter the edges.";

		for(int i=0;i<ele;i++)
		{
			string c;
				
			cin>>c;

			a[c[0]-97][c[2]-97] = 1;
		}
	}

	else
	{
		cout<<"\nNumber is invalid.";
	}

	show();
}


void graph::show()
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<a[i][j]<<" ";
		}
		cout<<endl;
	}
}


bool graph::check_complete()
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if( i != j)
			{
				if(a[i][j] == 0)
					return false;
			}

			else 
			{
				if(a[i][j] == 1)
					return false;
			}
				
		}
	}

	return true;
}


int main()
{
	graph g;
	
	g.enter();
	 
	if(g.check_complete())
	{
		cout<<"\nThe graph is complete.";
	}

	else
	{
		cout<<"\nThe graph is not complete.";
	}

return 0;
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    	
			                                                                                                                                                                                                                                                                                                        
