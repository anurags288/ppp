#include<iostream>
#include<cmath>
using namespace std;

int main()
{
	int i,m,n,l,h,choice;
	char ch;
	cout<<"\nEnter the number of internal nodes of the tree:";
	cin>>i;

	cout<<"\nEnter the value of m which indicates that the tree is an m-ary tree:";
	cin>>m;

	cout<<"\nEnter the heigth of the tree:";
	cin>>h;

	do
	{
		cout<<"\n1.Enter 1 to calculate the number of vertices in the tree.";
		cout<<"\n2.Enter 2 to calculate the number of leaves in the tree.";
		cout<<"\n3.Enter 3 to calculate maximum number of leaves in a tree with heigth "<<h<<" and is an "<<m<<"-ary tree";
		cout<<"\n\nEnter your choice:";
		cin>>choice;

		switch(choice)
		{
			case 1:n = m*i+1;
				cout<<"\nThe number of vertices in the tree are:"<<n;
				break;

			case 2:l = (m-1)*i+1;
				cout<<"\nThe number of leaves in the tree are:"<<l;
				break;

			case 3:l = pow(m,h);
				cout<<"\nThe maximum number of leaves in a tree of "<<m<<"-ary is:"<<l;
				break;

			default:cout<<"\nInvalid choice.";

		}

		cout<<"\nDo you want to enter another choice(y/n)?";
		cin>>ch;
	}while(ch == 'y' || ch == 'Y');

return 0;
}
