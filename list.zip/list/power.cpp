#include<iostream>
#include<cmath>
using namespace std;

void bin(int [],int);

int main()
{
	int a[10], sa;
	cout<<"\nEnter the size of the Set:";
	cin>>sa;

	cout<<"\nEnter the elements of the Set.";
	for(int i=0;i<sa;i++)
	{
		cout<<"\nEnter the element number "<<i+1<<":";
		cin>>a[i];
	}

	bin(a,sa);

return 0;

}


void bin(int a[],int sa)
{
	int length = pow(2,sa);

	int temp[sa];

	for(int i=0;i<length;i++)
	{	int k=0,t=i;
		while(k<sa)
		{	
			temp[k] = t%2;
			t /= 2;
			k++;
		}

	
	for(int j=0;j<k;j++)
	{
		if(temp[j] == 1)
			cout<<a[j]<<" ";
	}
	cout<<endl;
	}

}
