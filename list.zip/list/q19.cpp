#include<iostream>
#include<cmath>
using namespace std;

class graph
{
	int a[20][20];
	int n;

	public:
	graph();
	void enter();
	void show();
	void check_path_and_circuit();
};


graph::graph()
{
	n = 0;

	for(int i=0;i<20;i++)
	{
		for(int j=0;j<20;j++)
		{
			a[i][j] = 0;
		}
	}
}


void graph::enter()
{
	string ch;
	cout<<"\nEnter the number of elements you want to enter in the set:";
	cin>>n;
	
	cout<<"\nEnter the elements in the set as characters:";
	cin>>ch;

	int ele;

	cout<<"\nEnter the number of edges:";
	cin>>ele;

	if(ele >= 0 && ele <= pow(n,2))
	{
		cout<<"\n\nEnter the edges.";

		for(int i=0;i<ele;i++)
		{
			string c;
				
			cin>>c;

			a[c[0]-97][c[2]-97] = 1;
			a[c[2]-97][c[0]-97] = 1;
		}
	}

	else
	{
		cout<<"\nNumber is invalid.";
	}

	show();
}


void graph::show()
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<a[i][j]<<" ";
		}
		cout<<endl;
	}
}


void graph::check_path_and_circuit()
{
	int degree[n];

	for(int i=0;i<n;i++)
	{
		degree[i] = 0;

		for(int j=0;j<n;j++)
		{
			if(a[i][j] == 1)
			{
				degree[i] += 1;
			}
		}
	}

	int odd_count = 0;
	for(int i=0;i<n;i++)
	{
		if(degree[i] % 2 == 1)
			odd_count++;
	}

	if(odd_count == 0)
	{
		cout<<"\nThe graph has Euler Path as well as Euler Circuit.";
	}

	else if(odd_count == 2)
	{
		cout<<"\nThe graph has Euler Path.";
	}

	else
	{
		cout<<"\nThe graph has neither Euler path or circuit.";
	}

}	


int main()
{
	graph g;
	
	g.enter();
	 
	g.check_path_and_circuit();

return 0;
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    	
			                                                                                                                                                                                                                                                                                                        
